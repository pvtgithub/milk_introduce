<!DOCTYPE html>
<html>
<head>
	<title>Trang chủ</title>
	<link rel="stylesheet" type="text/css" href="trangchu1.css">
	<style type="text/css">
		#center a{
		color: blue;
	}
	</style>
</head>
<body background="image\nen.jpg" id="nen">
	<div id="container">
		<div id="logo"><span id="qc">QUẢNG CÁO SỮA VIỆT</span></div>
		<div id="menu">
			<ul>
				<li id="haha"><a href="trangchu.php">Trang Chủ</a></li>		
				<li><a href="giaodien.php">Thông Tin Hãng Sữa</a></li>
				<li><a href="thongtinsua.php">Thông Tin Sữa</a></li>
				<li><a href="thongtinkh.php">Thông Tin Khách Hàng</a></li>
				<li><a href="login.php">Đăng Nhập</a></li>
				<li><a href="giaodienadmin.php">Admin</a></li>

			</ul>
		</div>
		<div id="center">
			<div id="fristi">
				<table >
					<tr>
						<td colspan="2"><img src="image/fristi.jpg" height="200px" width="300px"></td>
					</tr>
					<tr>
						<td style="color: blue"><img src="image/logoDutchlady.jpg" height="30px" width="30px"> <a href="https://dutchlady.com.vn/" style="color: blue;">Dutch Lady</a></td>
						<td style="color: red">Lốc 6 chai 90ml<br>Ngon hơn khi uống lạnh<br>Giá: 22.000 ₫<a href="chitietsua.php?key=2">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>
			<div id="plus">
				<table>
					<tr>
						<td colspan="2"><img src="image/plus.jpg" height="200px" width="400px"></td>
					</tr>
					<tr>
						<td style="color: green"><img src="image/nutifood.jpg" height="30px" width="30px"><a href="https://nutifood.com.vn/" style="color: green">NutiFood</a></td>
						<td style="color: red">GrowPLUS+ Đỏ Cho Trẻ Suy Dinh Dưỡng<br> trên 1 Tuổi<br>Giá: 280.000 ₫ <a href="chitietsua.php?key=4">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>
			<div id="cghl">
				<table>
					<tr>
						<td colspan="2"><img src="image/cghl.jpg" height="200px" width="400px"></td>
					</tr>
					<tr>
						<td style="color: green"><img src="image/logoDutchlady.jpg" height="30px" width="30px"><a href="https://dutchlady.com.vn/" style="color: blue;">Dutch Lady</a></td>
						<td style="color: red">Sữa bột nguyên kem Dutch Lady Cô gái Hà Lan <br>Loại 900g<br>Giá: 239.000 ₫<a href="chitietsua.php?key=1">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>
			<div id="sure">
				<table>
					<tr>
						<td colspan="2"><img src="image/sure.jpg" height="200px" width="300px"></td>
					</tr>
					<tr>
						<td style="color: green"><img src="image/vinamilk.jpg" height="30px" width="30px"><a href="https://vinamilk.com.vn/" style="color: purple;">VinaMilk</a></td>
						<td style="color: red">Sữa Bột Vinamilk Sure Prevent<br>Hộp Thiếc 900g<br>Giá: 463.500 ₫<a href="chitietsua.php?key=5">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>
			<div id="grow">
				<table>
					<tr>
						<td colspan="2"><img src="image/grow.jpg" height="200px" width="300px"></td>
					</tr>
					<tr>
						<td style="color: green"><img src="image/abbott.jpg" height="30px" width="30px"><a href="https://abbott.com.vn/" style="color: orange;">Abbott</a></td>
						<td style="color: red">Sữa Bột Abbott Grow 3 <br>Lon 900gr<br>Giá: 260.000 ₫<a href="chitietsua.php?key=6">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>
			<div id="enfagrow">
				<table>
					<tr>
						<td colspan="2"><img src="image/enfagrow.jpg" height="200px" width="350px"></td>
					</tr>
					<tr>
						<td style="color: green"><img src="image/meadjonhson.jpg" height="30px" width="30px"><a href="https://meadjonhson.com.vn/" style="color: orange;">Mead Jonhson</a></td>
						<td style="color: red">
						Sữa bột Mead Johnson Enfagrow A+ 4<br>1.75 kg<br>Giá: 260.000 ₫<a href="chitietsua.php?key=7">Xem chi tiết>>></a></td>
					</tr>
				</table>
			</div>

		</div>
	</div>
</body>
</html>