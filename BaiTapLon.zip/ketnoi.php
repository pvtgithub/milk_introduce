<?php 
	$conn = mysqli_connect("localhost","root","","baitaplon") or die("kết nối thất bại");
	mysqli_set_charset($conn,"utf8");
 ?>